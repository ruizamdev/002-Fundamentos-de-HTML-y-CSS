# css-grid-basico
Classes for my CSS Grid Básico course on Platzi, here you'll find all the exercises that I'll be explaining
